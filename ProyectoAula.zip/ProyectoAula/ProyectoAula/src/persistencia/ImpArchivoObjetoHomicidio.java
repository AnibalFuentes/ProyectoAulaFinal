package persistencia;

import exepciones.ExcepcionArchivo;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import modelo.caso.Homicidio;

public class ImpArchivoObjetoHomicidio implements IHomicidioCrud {

    private File archivo;
    private FileInputStream modoLectura;
    private FileOutputStream modoEscritura;

    public ImpArchivoObjetoHomicidio() {
        this("Homicidios.obj");
    }

    public ImpArchivoObjetoHomicidio(String path) {
        this.archivo = new File(path);
    }

    private void guardar(List<Homicidio> lista) throws ExcepcionArchivo {
        ObjectOutputStream oos = null;
        try {
            this.modoEscritura = new FileOutputStream(this.archivo);
            oos = new ObjectOutputStream(this.modoEscritura);
            oos.writeObject(lista);
            oos.close();
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("El Archivo de escritura no existe, o no se puede abrir");
        } catch (SecurityException e) {
            throw new ExcepcionArchivo("No tiene permiso de escritura sobre el archivo");
        } catch (IOException e) {
            throw new ExcepcionArchivo("Error al escribir en el archivo");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivo("Los datos de la lista son null");
        }

    }

    private List<Homicidio> cargarArchivo() throws ExcepcionArchivo {
        ObjectInputStream ois = null;
        if (!this.archivo.exists()) {
            return new ArrayList<Homicidio>();
        }
        try {
            this.modoLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.modoLectura);
            List<Homicidio> lista = (List<Homicidio>) ois.readObject();
            ois.close();
            return lista;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("El Archivo de lectura no existe, o no se puede abrir");
        } catch (SecurityException e) {
            throw new ExcepcionArchivo("No tiene permiso de lectura sobre el archivo");
        } catch (StreamCorruptedException e) {
            throw new ExcepcionArchivo("Error con los datos de flujo de cierre del objeto");
        } catch (IOException e) {
            throw new ExcepcionArchivo("Error al leer en el archivo");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivo("El archivo a leer es null");
        } catch (ClassNotFoundException e) {
            throw new ExcepcionArchivo("No existe la claase definida para el objeto leido");
        }
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public FileInputStream getModoLectura() {
        return modoLectura;
    }

    public void setModoLectura(FileInputStream modoLectura) {
        this.modoLectura = modoLectura;
    }

    public FileOutputStream getModoEscritura() {
        return modoEscritura;
    }

    public void setModoEscritura(FileOutputStream modoEscritura) {
        this.modoEscritura = modoEscritura;
    }

    
    @Override
    public void registrar(Homicidio h) throws ExcepcionArchivo {
        List<Homicidio> lista = this.cargarArchivo();
        lista.add(h);
        this.guardar(lista);
    }

    @Override
    public List<Homicidio> leer() throws ExcepcionArchivo {
        return this.cargarArchivo();
    }

    @Override
    public Homicidio buscar(Homicidio h) throws ExcepcionArchivo {
        List<Homicidio> lista = this.cargarArchivo();
        Homicidio buscado = null;
        for (Homicidio homicidio : lista) {
            if (homicidio.getId() == (h.getId())) {
                buscado = homicidio;
                break;
            }
        }
        return buscado;
    }

    @Override
    public Homicidio eliminar(Homicidio h) throws ExcepcionArchivo {
        List<Homicidio> lista = this.cargarArchivo();
        Homicidio eliminar = null;
        Iterator<Homicidio> homicidio = lista.iterator();
        while (homicidio.hasNext()) {
            Homicidio aux = homicidio.next();
            if (aux.getId() == (h.getId())) {
                eliminar = aux;
                homicidio.remove();
            }
        }
        this.guardar(lista);

        return eliminar;
    }

    @Override
    public List<Homicidio> filtrar(int id) throws ExcepcionArchivo {
        List<Homicidio> lista = this.cargarArchivo();
        List<Homicidio> listaFiltrada = new ArrayList();
        for (Homicidio homicidio : lista) {
            int serialLista = homicidio.getId();
            int serialFiltrada = id;
            if (serialLista == serialFiltrada) {
                listaFiltrada.add(homicidio);
            }
        }
        return listaFiltrada;
    }

}
