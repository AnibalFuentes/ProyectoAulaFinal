package persistencia;

import exepciones.ExcepcionArchivo;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import modelo.caso.Cibercrimen;

public class ImpArchivoObjetoCibercrimen implements ICibercrimenCrud {

    private File archivo;
    private FileInputStream modoLectura;
    private FileOutputStream modoEscritura;

    public ImpArchivoObjetoCibercrimen() {
        this("Cibercrimenes.obj");
    }

    public ImpArchivoObjetoCibercrimen(String path) {
        this.archivo = new File(path);
    }

    private void guardar(List<Cibercrimen> lista) throws ExcepcionArchivo {
        ObjectOutputStream oos = null;
        try {
            this.modoEscritura = new FileOutputStream(this.archivo);
            oos = new ObjectOutputStream(this.modoEscritura);
            oos.writeObject(lista);
            oos.close();
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("El Archivo de escritura no existe, o no se puede abrir");
        } catch (SecurityException e) {
            throw new ExcepcionArchivo("No tiene permiso de escritura sobre el archivo");
        } catch (IOException e) {
            throw new ExcepcionArchivo("Error al escribir en el archivo");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivo("Los datos de la lista son null");
        }

    }

    private List<Cibercrimen> cargarArchivo() throws ExcepcionArchivo {
        ObjectInputStream ois = null;
        if (!this.archivo.exists()) {
            return new ArrayList<Cibercrimen>();
        }
        try {
            this.modoLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.modoLectura);
            List<Cibercrimen> lista = (List<Cibercrimen>) ois.readObject();
            ois.close();
            return lista;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("El Archivo de lectura no existe, o no se puede abrir");
        } catch (SecurityException e) {
            throw new ExcepcionArchivo("No tiene permiso de lectura sobre el archivo");
        } catch (StreamCorruptedException e) {
            throw new ExcepcionArchivo("Error con los datos de flujo de cierre del objeto");
        } catch (IOException e) {
            throw new ExcepcionArchivo("Error al leer en el archivo");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivo("El archivo a leer es null");
        } catch (ClassNotFoundException e) {
            throw new ExcepcionArchivo("No existe la claase definida para el objeto leido");
        }
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public FileInputStream getModoLectura() {
        return modoLectura;
    }

    public void setModoLectura(FileInputStream modoLectura) {
        this.modoLectura = modoLectura;
    }

    public FileOutputStream getModoEscritura() {
        return modoEscritura;
    }

    public void setModoEscritura(FileOutputStream modoEscritura) {
        this.modoEscritura = modoEscritura;
    }

    @Override
    public void registrar(Cibercrimen c) throws ExcepcionArchivo {
        List<Cibercrimen> lista = this.cargarArchivo();
        lista.add(c);
        this.guardar(lista);
    }

    @Override
    public List<Cibercrimen> leer() throws ExcepcionArchivo {
        return this.cargarArchivo();
    }

    @Override
    public Cibercrimen buscar(Cibercrimen c) throws ExcepcionArchivo {
        List<Cibercrimen> lista = this.cargarArchivo();
        Cibercrimen buscado = null;
        for (Cibercrimen cibercrimen : lista) {
            if (cibercrimen.getId() == (c.getId())) {
                buscado = cibercrimen;
                break;
            }
        }
        return buscado;
    }

    @Override
    public Cibercrimen eliminar(Cibercrimen c) throws ExcepcionArchivo {
        List<Cibercrimen> lista = this.cargarArchivo();
        Cibercrimen eliminar = null;
        Iterator<Cibercrimen> cibercrimen = lista.iterator();
        while (cibercrimen.hasNext()) {
            Cibercrimen aux = cibercrimen.next();
            if (aux.getId() == (c.getId())) {
                eliminar = aux;
                cibercrimen.remove();
            }
        }
        this.guardar(lista);

        return eliminar;
    }

    @Override
    public List<Cibercrimen> filtrar(int id) throws ExcepcionArchivo {
        List<Cibercrimen> lista = this.cargarArchivo();
        List<Cibercrimen> listaFiltrada = new ArrayList();
        for (Cibercrimen cibercrimen : lista) {
            int idLista = cibercrimen.getId();
            int idFiltrada = id;
            if (idLista == idFiltrada) {
                listaFiltrada.add(cibercrimen);
            }
        }
        return listaFiltrada;
    }

}
