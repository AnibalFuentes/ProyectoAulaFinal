package persistencia;

import exepciones.ExcepcionArchivo;
import java.util.List;
import modelo.caso.Cibercrimen;

public interface ICibercrimenCrud {
    void registrar(Cibercrimen h) throws ExcepcionArchivo;

    List<Cibercrimen> leer() throws ExcepcionArchivo;

    Cibercrimen buscar(Cibercrimen h) throws ExcepcionArchivo;

    Cibercrimen eliminar(Cibercrimen h) throws ExcepcionArchivo;

    List<Cibercrimen> filtrar(int id) throws ExcepcionArchivo;
}
