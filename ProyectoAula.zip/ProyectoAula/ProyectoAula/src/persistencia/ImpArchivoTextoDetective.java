package persistencia;

import exepciones.ExcepcionArchivo;
import java.io.*;
import java.util.*;
import modelo.persona.Detective;

public class ImpArchivoTextoDetective implements IDetectiveCrud {

    private File archivo;
    private FileWriter modoEscritura;
    private Scanner modoLectura;

    public ImpArchivoTextoDetective() {
        this("Detectives.inv");
    }

    public ImpArchivoTextoDetective(String path) {
        this.archivo = new File(path);
    }

    private Detective cargar(String data[]) {
        String id = String.valueOf(data[0]);
        String nombre = data[1];
        String apellido = data[2];
        int añosExperiencia = Integer.valueOf(data[3]);
        String tipoCaso = data[4];
        return new Detective(añosExperiencia, tipoCaso, id, nombre, apellido);
    }

    private void renombrarArchivo(File tmp) throws IOException {
        if (!tmp.exists()) {
            tmp.createNewFile();
        }
        if (!this.archivo.delete()) {
            throw new IOException("Error al eliminar el archivo principal");
        }
        if (!tmp.renameTo(this.archivo)) {
            throw new IOException("Error al renombrar el archivo tmp");
        }
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public FileWriter getModoEscritura() {
        return modoEscritura;
    }

    public void setModoEscritura(FileWriter modoEscritura) {
        this.modoEscritura = modoEscritura;
    }

    public Scanner getModoLectura() {
        return modoLectura;
    }

    public void setModoLectura(Scanner modoLectura) {
        this.modoLectura = modoLectura;
    }

    @Override
    public void registrar(Detective d) throws ExcepcionArchivo {
        PrintWriter pw = null;
        try {
            this.modoEscritura = new FileWriter(this.archivo, true);
            pw = new PrintWriter(this.modoEscritura);
            pw.println(d.obtenerAtributos());
        } catch (IOException e) {
            throw new ExcepcionArchivo("Error al abrir o crear archivo en modo escritura");
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }

    @Override
    public List<Detective> leer() throws ExcepcionArchivo {
        List<Detective> lista;
        try {
            this.modoLectura = new Scanner(this.archivo);
            lista = new ArrayList();
            while (this.modoLectura.hasNext()) {
                String[] data = this.modoLectura.nextLine().split(";");
                Detective d = this.cargar(data);
                lista.add(d);
            }
            return lista;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("Error al leer archivo en modo lectura");

        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    @Override
    public Detective buscar(Detective d) throws ExcepcionArchivo {
        Detective buscado = null;
        try {
            this.modoLectura = new Scanner(this.archivo);
            while (this.modoLectura.hasNext()) {
                String[] data = this.modoLectura.nextLine().split(";");
                buscado = this.cargar(data);
                if (buscado.getId().equals(d.getId())) {
                    return buscado;
                }
            }
            return null;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("Error al buscar archivo en modo lectura");
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    @Override
    public Detective eliminar(Detective d) throws ExcepcionArchivo {
        Detective eliminado = null;
        ImpArchivoTextoDetective archivoTemporal = new ImpArchivoTextoDetective("detectives.tmp");
        try {
            this.modoLectura = new Scanner(this.archivo);
            while (this.modoLectura.hasNext()) {
                String[] data = this.modoLectura.nextLine().split(";");
                Detective aux = this.cargar(data);
                if (aux.getId().equals(d.getId())) {
                    eliminado = aux;
                } else {
                    archivoTemporal.registrar(aux);
                }
            }
            this.modoLectura.close();
            this.renombrarArchivo(archivoTemporal.archivo);
            return eliminado;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("Error al buscar archivo en modo lectura");
        } catch (IOException e) {
            throw new ExcepcionArchivo(e.getMessage());
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    @Override
    public List<Detective> filtrar(int id) throws ExcepcionArchivo {
        List<Detective> lista = this.leer();
        List<Detective> listaFiltrada = new ArrayList();
        for (Detective detective : lista) {
            String idLista = String.valueOf(detective.getId());
            String isbnFiltrado = String.valueOf(id);
            if (idLista.contains(isbnFiltrado)) {
                listaFiltrada.add(detective);
            }
        }
        return listaFiltrada;
    }

}
