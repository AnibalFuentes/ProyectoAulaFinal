package persistencia;

import exepciones.ExcepcionArchivo;
import java.util.List;
import modelo.caso.Homicidio;

public interface IHomicidioCrud {

    void registrar(Homicidio h) throws ExcepcionArchivo;

    List<Homicidio> leer() throws ExcepcionArchivo;

    Homicidio buscar(Homicidio h) throws ExcepcionArchivo;

    Homicidio eliminar(Homicidio h) throws ExcepcionArchivo;

    List<Homicidio> filtrar(int id) throws ExcepcionArchivo;
}
