package persistencia;

import exepciones.ExcepcionArchivo;
import java.util.List;
import modelo.persona.Detective;

public interface IDetectiveCrud {

    void registrar(Detective d) throws ExcepcionArchivo;

    List<Detective> leer() throws ExcepcionArchivo;

    Detective buscar(Detective d) throws ExcepcionArchivo;

    Detective eliminar(Detective d) throws ExcepcionArchivo;

    List<Detective> filtrar(int id) throws ExcepcionArchivo;
}
