package persistencia;

import exepciones.ExcepcionArchivo;
import java.util.List;
import modelo.caso.Narcotico;

public interface INarcoticoCrud {
    void registrar(Narcotico h) throws ExcepcionArchivo;

    List<Narcotico> leer() throws ExcepcionArchivo;

    Narcotico buscar(Narcotico h) throws ExcepcionArchivo;

    Narcotico eliminar(Narcotico h) throws ExcepcionArchivo;

    List<Narcotico> filtrar(int id) throws ExcepcionArchivo;
}
