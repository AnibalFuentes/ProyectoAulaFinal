package vista.gui.consulta;

import exepciones.ExcepcionArchivo;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.caso.Homicidio;
import modelo.oficina.ListaHomicidioCrud;

public class GuiConsultaHomicidio extends JDialog {

    private JPanel panelBusqueda, panelPrinicipal, panelOpciones;
    private JScrollPane panelTabla;
    private JLabel lbBuqueda;
    private JButton btnEliminar;
    private JTextField txtBusqueda;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private String titulosTabla[] = {"ID", "CLAVE", "DESCRIPCION", "PRIORIDAD"};
    private String datosTabla[][] = {null};
    private Container contenedor;
    private ListaHomicidioCrud modelo;

    public GuiConsultaHomicidio(Frame frame, boolean bln) {
        super(frame, bln);
        this.modelo = new ListaHomicidioCrud();
        this.setTitle("HOMICIDIOS REGISTRADOS");
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        this.iniciarComponentes();
        this.setSize(500, 600);
        //this.pack();
        try {
            List<Homicidio> lista = this.modelo.leer();
            this.actualizarTabla(lista);
        } catch (ExcepcionArchivo e) {
        }
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void iniciarComponentes() {
        this.contenedor = this.getContentPane();
        this.contenedor.setLayout(new FlowLayout());
        this.panelPrinicipal = new JPanel();
        this.panelPrinicipal.setLayout(new BorderLayout());
        this.iniciarPanelBusqueda();
        this.iniciarPanelTabla();
        this.iniciarPanelOpciones();
        this.panelPrinicipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.contenedor.add(this.panelPrinicipal);
    }

    private void iniciarPanelBusqueda() {
        this.panelBusqueda = new JPanel();
        this.panelBusqueda.setLayout(new FlowLayout(FlowLayout.CENTER));
        this.lbBuqueda = new JLabel("N° ID: ");
        this.txtBusqueda = new JTextField(15);
        this.txtBusqueda.addKeyListener(new eventoFiltroBusqueda());
        this.panelBusqueda.add(this.lbBuqueda);
        this.panelBusqueda.add(this.txtBusqueda);
        this.panelBusqueda.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.panelPrinicipal.add(this.panelBusqueda, BorderLayout.NORTH);

    }

    private void iniciarPanelTabla() {
        this.tablaRegistros = new JTable();
        this.modeloTabla = new DefaultTableModel(this.datosTabla, this.titulosTabla);
        this.tablaRegistros.setModel(this.modeloTabla);
        this.panelTabla = new JScrollPane(this.tablaRegistros);
        this.panelPrinicipal.add(this.panelTabla, BorderLayout.CENTER);
    }

    private void iniciarPanelOpciones() {
        this.panelOpciones = new JPanel();
        this.panelOpciones.setLayout(new FlowLayout(FlowLayout.RIGHT));
        this.btnEliminar = new JButton("ELIMINAR CASO");
        this.btnEliminar.addActionListener(new eventoClickEliminar());
        this.panelOpciones.add(this.btnEliminar);
        this.panelOpciones.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.panelPrinicipal.add(this.panelOpciones, BorderLayout.SOUTH);
    }

    public void actualizarTabla(List<Homicidio> lista) {
        this.modeloTabla.setNumRows(0);
        for (Homicidio h : lista) {
            String datos[] = {String.valueOf(h.getId()), h.getClave(), h.getDescripcion(), h.getPrioridad()};
            this.modeloTabla.addRow(datos);
        }
    }

    private void filtrarDatos() {
        try {
            int id;
            List<Homicidio> lista;
            if (this.txtBusqueda.getText().isEmpty()) {
                id = 0;
                lista = this.modelo.leer();
            } else {
                id = Integer.valueOf(this.txtBusqueda.getText());
                lista = this.modelo.filtrar(id);
            }
            this.actualizarTabla(lista);
        } catch (ExcepcionArchivo e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    private void eliminarDato() {
        int row = this.tablaRegistros.getSelectedRow();
        int idEliminado = (int) this.modeloTabla.getValueAt(row, 0);
        try {
            Homicidio eliminado = this.modelo.eliminar(new Homicidio(idEliminado));
            this.filtrarDatos();
            JOptionPane.showMessageDialog(null, "LIBRO ELIMINADO CORRECTAMENTE", " ATENCIÓN", JOptionPane.WARNING_MESSAGE);
        } catch (ExcepcionArchivo e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    class eventoFiltroBusqueda implements KeyListener {
        @Override
        public void keyTyped(KeyEvent e) {
            int key = e.getKeyChar();
            boolean numeros = key >= 48 && key <= 57; //Rango de letras MAYUSCULAS en ASCII
            boolean retroceso = key == 8; //Retroceso en ASCII
            boolean enter = key == 13; //Enter en ASCII
            if (!(numeros || retroceso || enter)) {
                JOptionPane.showMessageDialog(null, "SOLO SE PERMITE EL INGRERSO DE NÚMEROS.");
                e.consume();
            }
        }

        @Override
        public void keyPressed(KeyEvent e) {
            filtrarDatos();

        }

        @Override
        public void keyReleased(KeyEvent e) {
            filtrarDatos();
        }
    }

    class eventoClickEliminar implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            eliminarDato();
        }
    }
}
