package vista.gui.consulta;

import exepciones.ExcepcionArchivo;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.oficina.ListaDetectiveCrud;
import modelo.persona.Detective;

public class GuiConsultaDetective extends JDialog {

    private JPanel panelBusqueda, panelPrinicipal, panelOpciones;
    private JScrollPane panelTabla;
    private JLabel lbBuqueda;
    private JButton btnEliminar;
    private JTextField txtBusqueda;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private String titulosTabla[] = {"IDENTIFICACIÓN", "NOMBRE", "APELLIDO", "EXPERIENCIA", "TIPO DE CASO"};
    private String datosTabla[][] = {null};
    private Container contenedor;
    private ListaDetectiveCrud modelo;

    public GuiConsultaDetective(Frame frame, boolean bln) {
        super(frame, bln);
        this.modelo = new ListaDetectiveCrud();
        this.setTitle("REGISTRO DE DETECTIVES");
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        this.iniciarComponentes();
        this.setSize(500, 600);
        //this.pack();
        try {
            List<Detective> lista = this.modelo.leer();
            this.actualizarTabla(lista);
        } catch (ExcepcionArchivo e) {
        }
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void iniciarComponentes() {
        this.contenedor = this.getContentPane();
        this.contenedor.setLayout(new FlowLayout());
        this.panelPrinicipal = new JPanel();
        this.panelPrinicipal.setLayout(new BorderLayout());
        this.iniciarPanelBusqueda();
        this.iniciarPanelTabla();
        this.iniciarPanelOpciones();
        this.panelPrinicipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.contenedor.add(this.panelPrinicipal);
    }

    private void iniciarPanelBusqueda() {
        this.panelBusqueda = new JPanel();
        this.panelBusqueda.setLayout(new FlowLayout(FlowLayout.CENTER));
        this.lbBuqueda = new JLabel("IDENTIFICACIÓN: ");
        this.txtBusqueda = new JTextField(15);
        this.txtBusqueda.addKeyListener(new eventoFiltroBusqueda());
        this.panelBusqueda.add(this.lbBuqueda);
        this.panelBusqueda.add(this.txtBusqueda);
        this.panelBusqueda.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.panelPrinicipal.add(this.panelBusqueda, BorderLayout.NORTH);
    }

    private void iniciarPanelTabla() {
        this.tablaRegistros = new JTable();
        this.modeloTabla = new DefaultTableModel(this.datosTabla, this.titulosTabla);
        this.tablaRegistros.setModel(this.modeloTabla);
        this.panelTabla = new JScrollPane(this.tablaRegistros);
        this.panelPrinicipal.add(this.panelTabla, BorderLayout.CENTER);
    }

    private void iniciarPanelOpciones() {
        this.panelOpciones = new JPanel();
        this.panelOpciones.setLayout(new FlowLayout(FlowLayout.RIGHT));
        this.btnEliminar = new JButton("ELIMINAR DETECTIVE");
        this.btnEliminar.addActionListener(new eventoClickEliminar());
        this.panelOpciones.add(this.btnEliminar);
        this.panelOpciones.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.panelPrinicipal.add(this.panelOpciones, BorderLayout.SOUTH);
    }

    public void actualizarTabla(List<Detective> lista) {
        this.modeloTabla.setNumRows(0);
        for (Detective d : lista) {
            String datos[] = {String.valueOf(d.getId()), d.getNombre(), String.valueOf(d.getApellido()), String.valueOf(d.getAñosExperiencia()+" AÑOS"), String.valueOf(d.getTipoCaso())};
            this.modeloTabla.addRow(datos);
        }
    }

    private void filtrarDatos() {
        try {
            int id;
            List<Detective> lista;
            if (this.txtBusqueda.getText().isEmpty()) {
                id = 0;
                lista = this.modelo.leer();
            } else {
                id = Integer.valueOf(this.txtBusqueda.getText());
                lista = this.modelo.filtrar(id);
            }
            this.actualizarTabla(lista);
        } catch (ExcepcionArchivo e) {
        }

    }

    private void eliminarDato() {
        int row = this.tablaRegistros.getSelectedRow();
        String idEliminado = (String) this.modeloTabla.getValueAt(row, 0);
        try {
            Detective eliminado = this.modelo.eliminar(new Detective(String.valueOf(idEliminado)));
            JOptionPane.showMessageDialog(null, "DETECTIVE ELIMINADO");
            this.filtrarDatos();
        } catch (ExcepcionArchivo e) {
        }
    }

    class eventoFiltroBusqueda implements KeyListener {

        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {
            filtrarDatos();
        }

    }

    class eventoClickEliminar implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            eliminarDato();
        }

    }
}
