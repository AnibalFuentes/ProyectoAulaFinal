package vista.gui.principal;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.IOException;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class GuiLogin extends javax.swing.JFrame {

    public GuiLogin() {
        initComponents();
    }

    //Mover ventana
    int xMouse;
    int yMouse;


    void ingresar() {
        String usuario = "Admin";
        String contraseña = "Admin";
        String pass = new String(ing_contraseña.getPassword());
        if (ing_usuario.getText().equals(usuario) && pass.equals(contraseña)) {
            Icon check;
            check = new ImageIcon("src\\casocerrado\\vista\\gui\\imagenes\\secundarias\\Check.png");
            JOptionPane.showMessageDialog(null, "Iniciando sesión...", "Caso Cerrado", JOptionPane.WARNING_MESSAGE, check);
            GuiMenuInicio principal = new GuiMenuInicio();
            principal.setVisible(true);
            this.dispose();
        } else if (!ing_usuario.getText().equals(usuario) && !pass.equals(contraseña)) {
            JOptionPane.showMessageDialog(null, "Usuario y contraseña incorrectos.", "Caso Cerrado", JOptionPane.ERROR_MESSAGE);
            ing_usuario.requestFocus(true);
        } else if (!ing_usuario.getText().equals(usuario)) {
            JOptionPane.showMessageDialog(null, "Usuario incorrecto", "Caso Cerrado", JOptionPane.ERROR_MESSAGE);
            ing_usuario.requestFocus(true);
        } else if (!pass.equals(contraseña)) {
            JOptionPane.showMessageDialog(null, "Contraseña incorrecta", "Caso Cerrado", JOptionPane.ERROR_MESSAGE);
            ing_contraseña.requestFocus(true);
        }
    }

    void salir() {
        Icon IcoSalir;
        IcoSalir = new ImageIcon("src\\vista\\gui\\imagenes\\sad.png");
        Icon no;
        no = new ImageIcon("src\\vista\\gui\\imagenes\\happy.png");
        Icon si;
        si = new ImageIcon("src\\vista\\gui\\imagenes\\conf.png");
        int reply = JOptionPane.showConfirmDialog(null, "¿Desea salir?", "Atención", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, IcoSalir);
        if (reply == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "Sistema finalizdo.", "Caso Cerrado", JOptionPane.WARNING_MESSAGE, si);
            System.exit(0);
        } else {
            JOptionPane.showMessageDialog(null, "Acción cancelada.", "Caso Cerrado", JOptionPane.WARNING_MESSAGE, no);
        }
    }

    void mayus() {
        boolean mayActivo = Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK);
        if (mayActivo) {
            txt_may.setText("(Bloq Mayús activado)");
        } else {
            txt_may.setText("");
        }
    }

    void enter(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            ingresar();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pa_superior = new javax.swing.JPanel();
        tx_titulo = new javax.swing.JLabel();
        bt_salir = new javax.swing.JLabel();
        portada = new javax.swing.JLabel();
        baseLogin = new javax.swing.JPanel();
        img_logo = new javax.swing.JLabel();
        tx_bienvenido = new javax.swing.JLabel();
        tx_instrucciones = new javax.swing.JLabel();
        tx_usuario = new javax.swing.JLabel();
        tx_contraseña = new javax.swing.JLabel();
        txt_may = new javax.swing.JLabel();
        ing_usuario = new javax.swing.JTextField();
        ing_contraseña = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pa_superior.setBackground(new java.awt.Color(2, 48, 89));
        pa_superior.setCursor(new java.awt.Cursor(java.awt.Cursor.MOVE_CURSOR));
        pa_superior.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                pa_superiorMouseDragged(evt);
            }
        });
        pa_superior.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pa_superiorMousePressed(evt);
            }
        });
        pa_superior.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tx_titulo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        tx_titulo.setForeground(new java.awt.Color(255, 255, 255));
        tx_titulo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/log.png"))); // NOI18N
        tx_titulo.setText("CASO CERRADO SOFTWARE V1.0");
        pa_superior.add(tx_titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, 16));

        bt_salir.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bt_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/Quit.png"))); // NOI18N
        bt_salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bt_salir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_salirMouseClicked(evt);
            }
        });
        pa_superior.add(bt_salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 0, 30, 30));

        getContentPane().add(pa_superior, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 30));

        portada.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/portada.png"))); // NOI18N
        getContentPane().add(portada, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, -1, 470));

        baseLogin.setBackground(new java.awt.Color(2, 62, 115));
        baseLogin.setMaximumSize(new java.awt.Dimension(400, 500));
        baseLogin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        img_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        img_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/logo.png"))); // NOI18N
        baseLogin.add(img_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 380, -1));

        tx_bienvenido.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        tx_bienvenido.setForeground(new java.awt.Color(255, 255, 255));
        tx_bienvenido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tx_bienvenido.setText("BIENVENIDO");
        baseLogin.add(tx_bienvenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 380, -1));

        tx_instrucciones.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        tx_instrucciones.setForeground(new java.awt.Color(204, 204, 204));
        tx_instrucciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tx_instrucciones.setText("Ingrese los siguientes datos de manera correcta:");
        baseLogin.add(tx_instrucciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 380, -1));

        tx_usuario.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        tx_usuario.setForeground(new java.awt.Color(255, 255, 255));
        tx_usuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tx_usuario.setText("USUARIO:");
        baseLogin.add(tx_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 200, -1));

        tx_contraseña.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        tx_contraseña.setForeground(new java.awt.Color(255, 255, 255));
        tx_contraseña.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tx_contraseña.setText("CONTRASEÑA:");
        baseLogin.add(tx_contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 330, 200, -1));

        txt_may.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txt_may.setForeground(new java.awt.Color(255, 255, 255));
        txt_may.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        baseLogin.add(txt_may, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, 200, 20));

        ing_usuario.setBackground(new java.awt.Color(2, 48, 89));
        ing_usuario.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ing_usuario.setForeground(new java.awt.Color(255, 255, 255));
        ing_usuario.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ing_usuario.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(2, 32, 57)));
        ing_usuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ing_usuarioKeyReleased(evt);
            }
        });
        baseLogin.add(ing_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 280, 200, 30));

        ing_contraseña.setBackground(new java.awt.Color(2, 48, 89));
        ing_contraseña.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ing_contraseña.setForeground(new java.awt.Color(255, 255, 255));
        ing_contraseña.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ing_contraseña.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(2, 32, 57)));
        ing_contraseña.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ing_contraseñaKeyReleased(evt);
            }
        });
        baseLogin.add(ing_contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 350, 200, 30));

        jButton1.setBackground(new java.awt.Color(2, 48, 89));
        jButton1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("INGRESAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        baseLogin.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 420, 200, 40));

        getContentPane().add(baseLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, 400, 500));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void bt_salirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_salirMouseClicked
        salir();
    }//GEN-LAST:event_bt_salirMouseClicked

    private void pa_superiorMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pa_superiorMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_pa_superiorMouseDragged

    private void pa_superiorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pa_superiorMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_pa_superiorMousePressed

    private void ing_usuarioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ing_usuarioKeyReleased
        mayus();
    }//GEN-LAST:event_ing_usuarioKeyReleased

    private void ing_contraseñaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ing_contraseñaKeyReleased
        mayus();
        enter(evt);
    }//GEN-LAST:event_ing_contraseñaKeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        ingresar();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GuiLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GuiLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GuiLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GuiLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GuiLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel baseLogin;
    private javax.swing.JLabel bt_salir;
    private javax.swing.JLabel img_logo;
    private javax.swing.JPasswordField ing_contraseña;
    private javax.swing.JTextField ing_usuario;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel pa_superior;
    private javax.swing.JLabel portada;
    private javax.swing.JLabel tx_bienvenido;
    private javax.swing.JLabel tx_contraseña;
    private javax.swing.JLabel tx_instrucciones;
    private javax.swing.JLabel tx_titulo;
    private javax.swing.JLabel tx_usuario;
    private javax.swing.JLabel txt_may;
    // End of variables declaration//GEN-END:variables
}
