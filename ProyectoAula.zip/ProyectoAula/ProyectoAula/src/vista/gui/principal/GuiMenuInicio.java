package vista.gui.principal;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import vista.gui.consulta.GuiConsultaDetective;
import vista.gui.registro.GuiRegistroDetective;

public class GuiMenuInicio extends javax.swing.JFrame {

    public GuiMenuInicio() {
        initComponents();
    }

    void minimizar() {
        this.setExtendedState(ICONIFIED);
    }

    void salir() {
        Icon in;
        in = new ImageIcon("src\\vista\\gui\\imagenes\\info.png");
        Icon no;
        no = new ImageIcon("src\\vista\\gui\\imagenes\\cancelar.png");
        Icon si;
        si = new ImageIcon("src\\vista\\gui\\imagenes\\abortar.png");
        int reply = JOptionPane.showConfirmDialog(null, "¿Desea salir?", "Atención", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, in);

        if (reply == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "Sistema finalizdo.", "Atención", JOptionPane.WARNING_MESSAGE, si);
            System.exit(0);
        } else {
            JOptionPane.showMessageDialog(null, "Acción cancelada.", "Atención", JOptionPane.WARNING_MESSAGE, no);
        }
    }

    void acercaDe() {
        Icon check;
        check = new ImageIcon("src\\vista\\gui\\imagenes\\user.png");
        JOptionPane.showMessageDialog(null, "CREADO POR:\nANGEL CHAVEZ Y ANIBAL FUENTES.", " INFORMACIÓN DEL SISTEMA", JOptionPane.WARNING_MESSAGE, check);
    }

    //Mover ventana
    int xMouse;
    int yMouse;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        base = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        menu = new javax.swing.JMenuBar();
        casos = new javax.swing.JMenu();
        registrar = new javax.swing.JMenuItem();
        consultar = new javax.swing.JMenuItem();
        Detectives = new javax.swing.JMenu();
        Reg_detective = new javax.swing.JMenuItem();
        Con_detective = new javax.swing.JMenuItem();
        info = new javax.swing.JMenu();
        acerca = new javax.swing.JMenuItem();
        miniminzar = new javax.swing.JMenuItem();
        salir = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        base.setBackground(new java.awt.Color(2, 62, 115));
        base.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Caso Cerrado Software V1.0");
        base.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(605, 450, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/fondoBase.png"))); // NOI18N
        base.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        menu.setBackground(new java.awt.Color(2, 48, 89));
        menu.setBorder(null);
        menu.setForeground(new java.awt.Color(255, 255, 255));
        menu.setAlignmentX(0.0F);
        menu.setBorderPainted(false);
        menu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        menu.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        menu.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                menuMouseDragged(evt);
            }
        });
        menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                menuMousePressed(evt);
            }
        });

        casos.setBackground(new java.awt.Color(2, 48, 89));
        casos.setForeground(new java.awt.Color(255, 255, 255));
        casos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/ss.png"))); // NOI18N
        casos.setText("Casos");

        registrar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        registrar.setBackground(new java.awt.Color(2, 48, 89));
        registrar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        registrar.setForeground(new java.awt.Color(255, 255, 255));
        registrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/editar_1.png"))); // NOI18N
        registrar.setText("Registrar");
        registrar.setToolTipText("Consultar");
        registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarActionPerformed(evt);
            }
        });
        casos.add(registrar);

        consultar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        consultar.setBackground(new java.awt.Color(2, 48, 89));
        consultar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        consultar.setForeground(new java.awt.Color(255, 255, 255));
        consultar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/buscar.png"))); // NOI18N
        consultar.setText("Consultar");
        consultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consultarActionPerformed(evt);
            }
        });
        casos.add(consultar);

        menu.add(casos);

        Detectives.setBackground(new java.awt.Color(2, 48, 89));
        Detectives.setForeground(new java.awt.Color(255, 255, 255));
        Detectives.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/log.png"))); // NOI18N
        Detectives.setText("Detectives");

        Reg_detective.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        Reg_detective.setBackground(new java.awt.Color(2, 48, 89));
        Reg_detective.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Reg_detective.setForeground(new java.awt.Color(255, 255, 255));
        Reg_detective.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/editar_1.png"))); // NOI18N
        Reg_detective.setText("Registrar");
        Reg_detective.setToolTipText("");
        Reg_detective.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Reg_detectiveActionPerformed(evt);
            }
        });
        Detectives.add(Reg_detective);

        Con_detective.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        Con_detective.setBackground(new java.awt.Color(2, 48, 89));
        Con_detective.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Con_detective.setForeground(new java.awt.Color(255, 255, 255));
        Con_detective.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/buscar.png"))); // NOI18N
        Con_detective.setText("Consultar");
        Con_detective.setToolTipText("");
        Con_detective.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Con_detectiveActionPerformed(evt);
            }
        });
        Detectives.add(Con_detective);

        menu.add(Detectives);

        info.setBackground(new java.awt.Color(2, 48, 89));
        info.setForeground(new java.awt.Color(255, 255, 255));
        info.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/menu.png"))); // NOI18N
        info.setText("Opciones");
        info.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                infoActionPerformed(evt);
            }
        });

        acerca.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        acerca.setBackground(new java.awt.Color(2, 48, 89));
        acerca.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        acerca.setForeground(new java.awt.Color(255, 255, 255));
        acerca.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/acerca.png"))); // NOI18N
        acerca.setText("Acerca de");
        acerca.setToolTipText("Consultar");
        acerca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acercaActionPerformed(evt);
            }
        });
        info.add(acerca);

        miniminzar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        miniminzar.setBackground(new java.awt.Color(2, 48, 89));
        miniminzar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        miniminzar.setForeground(new java.awt.Color(255, 255, 255));
        miniminzar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/min_1.png"))); // NOI18N
        miniminzar.setText("Minimizar");
        miniminzar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miniminzarActionPerformed(evt);
            }
        });
        info.add(miniminzar);

        salir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        salir.setBackground(new java.awt.Color(2, 48, 89));
        salir.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        salir.setForeground(new java.awt.Color(255, 255, 255));
        salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/salir.png"))); // NOI18N
        salir.setText("Salir");
        salir.setToolTipText("Consultar");
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirActionPerformed(evt);
            }
        });
        info.add(salir);

        menu.add(info);

        setJMenuBar(menu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(base, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(base, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarActionPerformed
        GuiEscogerRegistro registrar = new GuiEscogerRegistro(this, true);
        registrar.setVisible(true);
    }//GEN-LAST:event_registrarActionPerformed

    private void consultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consultarActionPerformed
        GuiEscogerConsulta consultar = new GuiEscogerConsulta(this, true);
        consultar.setVisible(true);
    }//GEN-LAST:event_consultarActionPerformed

    private void Reg_detectiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Reg_detectiveActionPerformed
        GuiRegistroDetective regDetective = new GuiRegistroDetective(this, true);
        regDetective.setVisible(true);
    }//GEN-LAST:event_Reg_detectiveActionPerformed

    private void Con_detectiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Con_detectiveActionPerformed
        new GuiConsultaDetective(this, true);
    }//GEN-LAST:event_Con_detectiveActionPerformed

    private void acercaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acercaActionPerformed
        acercaDe();
    }//GEN-LAST:event_acercaActionPerformed

    private void miniminzarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miniminzarActionPerformed
        minimizar();
    }//GEN-LAST:event_miniminzarActionPerformed

    private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
        salir();
    }//GEN-LAST:event_salirActionPerformed

    private void infoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_infoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_infoActionPerformed

    private void menuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_menuMousePressed

    private void menuMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_menuMouseDragged

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GuiMenuInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GuiMenuInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GuiMenuInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GuiMenuInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GuiMenuInicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Con_detective;
    private javax.swing.JMenu Detectives;
    private javax.swing.JMenuItem Reg_detective;
    private javax.swing.JMenuItem acerca;
    private javax.swing.JPanel base;
    private javax.swing.JMenu casos;
    private javax.swing.JMenuItem consultar;
    private javax.swing.JMenu info;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar menu;
    private javax.swing.JMenuItem miniminzar;
    private javax.swing.JMenuItem registrar;
    private javax.swing.JMenuItem salir;
    // End of variables declaration//GEN-END:variables
}
