package vista.gui.principal;

import javax.swing.JOptionPane;
import vista.gui.consulta.GuiConsultaCibercrimen;
import vista.gui.consulta.GuiConsultaHomicidio;

public class GuiEscogerConsulta extends javax.swing.JDialog {

    public GuiEscogerConsulta(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        base = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        bt_homicidio = new javax.swing.JButton();
        bt_cibercrimen = new javax.swing.JButton();
        bt_narcotico = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        base.setBackground(new java.awt.Color(2, 62, 115));

        jLabel1.setBackground(new java.awt.Color(2, 48, 89));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Tipo de caso a consultar:");

        bt_homicidio.setBackground(new java.awt.Color(2, 48, 89));
        bt_homicidio.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bt_homicidio.setForeground(new java.awt.Color(255, 255, 255));
        bt_homicidio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/buscar.png"))); // NOI18N
        bt_homicidio.setText("Homicidio");
        bt_homicidio.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bt_homicidio.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        bt_homicidio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_homicidioActionPerformed(evt);
            }
        });

        bt_cibercrimen.setBackground(new java.awt.Color(2, 48, 89));
        bt_cibercrimen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bt_cibercrimen.setForeground(new java.awt.Color(255, 255, 255));
        bt_cibercrimen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/buscar.png"))); // NOI18N
        bt_cibercrimen.setText("Cibercrimen");
        bt_cibercrimen.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bt_cibercrimen.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        bt_cibercrimen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_cibercrimenActionPerformed(evt);
            }
        });

        bt_narcotico.setBackground(new java.awt.Color(2, 48, 89));
        bt_narcotico.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bt_narcotico.setForeground(new java.awt.Color(255, 255, 255));
        bt_narcotico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/gui/imagenes/buscar.png"))); // NOI18N
        bt_narcotico.setText("Narcotico");
        bt_narcotico.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bt_narcotico.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);

        javax.swing.GroupLayout baseLayout = new javax.swing.GroupLayout(base);
        base.setLayout(baseLayout);
        baseLayout.setHorizontalGroup(
            baseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(baseLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(baseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bt_homicidio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bt_cibercrimen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bt_narcotico, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        baseLayout.setVerticalGroup(
            baseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(baseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bt_homicidio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bt_cibercrimen)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bt_narcotico)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(base, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(base, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void bt_homicidioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_homicidioActionPerformed
        new GuiConsultaHomicidio(null, true);
    }//GEN-LAST:event_bt_homicidioActionPerformed

    private void bt_cibercrimenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_cibercrimenActionPerformed
        try {
            new GuiConsultaCibercrimen(null, true);
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "ERROR: " + e);
        }

    }//GEN-LAST:event_bt_cibercrimenActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GuiEscogerConsulta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GuiEscogerConsulta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GuiEscogerConsulta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GuiEscogerConsulta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                GuiEscogerConsulta dialog = new GuiEscogerConsulta(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel base;
    private javax.swing.JButton bt_cibercrimen;
    private javax.swing.JButton bt_homicidio;
    private javax.swing.JButton bt_narcotico;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
