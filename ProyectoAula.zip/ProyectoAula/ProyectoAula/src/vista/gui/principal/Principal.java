package vista.gui.principal;

public class Principal {

    public static void main(String[] args) {
        GuiLogin inicio = new GuiLogin();
        inicio.setVisible(true);
    }
}
