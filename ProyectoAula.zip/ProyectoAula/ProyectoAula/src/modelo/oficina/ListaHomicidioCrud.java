package modelo.oficina;

import exepciones.ExcepcionArchivo;
import java.util.List;
import modelo.caso.Homicidio;
import persistencia.IHomicidioCrud;
import persistencia.ImpArchivoObjetoHomicidio;

public class ListaHomicidioCrud implements IHomicidioCrud {

    private IHomicidioCrud baseDatos = new ImpArchivoObjetoHomicidio();

    @Override
    public void registrar(Homicidio h) throws ExcepcionArchivo {
        this.baseDatos.registrar(h);
    }

    @Override
    public List<Homicidio> leer() throws ExcepcionArchivo {
        return this.baseDatos.leer();
    }

    @Override
    public Homicidio buscar(Homicidio h) throws ExcepcionArchivo {
        return this.baseDatos.buscar(h);
    }

    @Override
    public Homicidio eliminar(Homicidio h) throws ExcepcionArchivo {
        return this.baseDatos.eliminar(h);
    }

    @Override
    public List<Homicidio> filtrar(int id) throws ExcepcionArchivo {
        return this.baseDatos.filtrar(id);
    }
}
