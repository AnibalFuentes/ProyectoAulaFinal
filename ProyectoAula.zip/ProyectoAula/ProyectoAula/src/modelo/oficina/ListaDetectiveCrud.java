package modelo.oficina;

import exepciones.ExcepcionArchivo;
import java.util.List;
import modelo.persona.Detective;
import persistencia.IDetectiveCrud;
import persistencia.ImpArchivoTextoDetective;

public class ListaDetectiveCrud implements IDetectiveCrud {

    private IDetectiveCrud baseDatos = new ImpArchivoTextoDetective();

    @Override
    public void registrar(Detective d) throws ExcepcionArchivo {
        this.baseDatos.registrar(d);
    }

    @Override
    public List<Detective> leer() throws ExcepcionArchivo {
        return this.baseDatos.leer();
    }

    @Override
    public Detective buscar(Detective d) throws ExcepcionArchivo {
        return this.baseDatos.buscar(d);
    }

    @Override
    public Detective eliminar(Detective d) throws ExcepcionArchivo {
        return this.baseDatos.eliminar(d);
    }

    @Override
    public List<Detective> filtrar(int id) throws ExcepcionArchivo {
        return this.baseDatos.filtrar(id);
    }

}
