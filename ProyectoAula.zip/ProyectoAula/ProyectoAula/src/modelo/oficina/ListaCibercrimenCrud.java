package modelo.oficina;

import exepciones.ExcepcionArchivo;
import java.util.List;
import modelo.caso.Cibercrimen;
import persistencia.ICibercrimenCrud;
import persistencia.ImpArchivoObjetoCibercrimen;

public class ListaCibercrimenCrud implements ICibercrimenCrud {

    private ICibercrimenCrud baseDatos = new ImpArchivoObjetoCibercrimen();

    @Override
    public void registrar(Cibercrimen c) throws ExcepcionArchivo {
        this.baseDatos.registrar(c);
    }

    @Override
    public List<Cibercrimen> leer() throws ExcepcionArchivo {
        return this.baseDatos.leer();
    }

    @Override
    public Cibercrimen buscar(Cibercrimen c) throws ExcepcionArchivo {
        return this.baseDatos.buscar(c);
    }

    @Override
    public Cibercrimen eliminar(Cibercrimen c) throws ExcepcionArchivo {
        return this.baseDatos.eliminar(c);
    }

    @Override
    public List<Cibercrimen> filtrar(int id) throws ExcepcionArchivo {
        return this.baseDatos.filtrar(id);
    }
}
