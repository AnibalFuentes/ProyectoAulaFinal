package modelo.oficina;

import java.util.ArrayList;
import modelo.caso.Caso;
import modelo.persona.Detective;
import modelo.persona.Sospechoso;

public class Oficina {

    protected ArrayList<Caso> casos;
    protected ArrayList<Detective> detectives;
    protected ArrayList<Sospechoso> sospechosos;

    public Oficina() {
    }


    public ArrayList<Caso> getCasos() {
        return casos;
    }

    public ArrayList<Detective> getDetectives() {
        return detectives;
    }

    public ArrayList<Sospechoso> getSospechosos() {
        return sospechosos;
    }

    public void setCasos(ArrayList<Caso> casos) {
        this.casos = casos;
    }

    public void setDetectives(ArrayList<Detective> detectives) {
        this.detectives = detectives;
    }

    public void setSospechosos(ArrayList<Sospechoso> sospechosos) {
        this.sospechosos = sospechosos;
    }

}
