package modelo.caso;

import java.util.ArrayList;
import modelo.bitacora.Bitacora;
import modelo.persona.Detective;
import modelo.persona.Sospechoso;

public class Cibercrimen extends Caso {

    private String cibercrimenAsociado;

    public Cibercrimen() {
    }

    public Cibercrimen(int id) {
        super(id);
    }

    public Cibercrimen(String cibercrimenAsociado, String clave, String descripcion, String prioridad, Bitacora bitacora, Detective detective, ArrayList<Sospechoso> sospechosos) {
        super(clave, descripcion, prioridad, bitacora, detective, sospechosos);
        this.cibercrimenAsociado = cibercrimenAsociado;
    }

    public String getCibercrimenAsociado() {
        return cibercrimenAsociado;
    }

    public void setCibercrimenAsociado(String cibercrimenAsociado) {
        this.cibercrimenAsociado = cibercrimenAsociado;
    }

    @Override
    public String toString() {
        return "Cibercrimen{" + "cibercrimenAsociado=" + cibercrimenAsociado + super.toString() + '}';
    }

    @Override
    public String mostrarAtributos() {
        return this.id + ";" + cibercrimenAsociado + ";" + this.clave + ";" + this.descripcion + ";"
                + this.prioridad + ";" + this.bitacora + ";" + this.detective + ";" + this.sospechosos;
    }

}
